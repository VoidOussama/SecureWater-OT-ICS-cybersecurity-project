# Contribuer

Ce dépôt documente un laboratoire de cybersécurité industrielle réalisé dans le cadre d'un
Projet de Fin d'Année. Les contributions sont bienvenues, en particulier sur trois axes.

## Ce qui est utile

- **Corrections techniques** — une erreur de configuration, une commande obsolète, une
  imprécision sur un protocole industriel.
- **Traitement des écarts ouverts** — les trois constats documentés dans
  `docs/05-findings.md` attendent une correction vérifiée.
- **Extension de la couverture de détection** — règles Suricata dédiées aux codes de
  fonction Modbus, règles de corrélation Wazuh, intégration de Zeek.

## Règle de fond

Ce dépôt distingue systématiquement **ce qui est déployé** de **ce qui est démontré**.
Une contribution qui affirme un résultat doit fournir la preuve correspondante : capture
horodatée, extrait de journal, ou commande reproductible.

Aucune configuration ni aucun résultat ne doit être reconstitué de mémoire ou supposé.

## Ce qui n'est pas accepté

- Toute configuration destinée à un environnement de production réel.
- Tout code offensif dépassant la reconnaissance et le balayage de ports.
- Toute capture contenant des identifiants, des clés ou des adresses d'une installation réelle.
