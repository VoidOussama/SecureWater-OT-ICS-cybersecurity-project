#!/usr/bin/env bash
# SecureWater OT — Tests de segmentation depuis la zone IT (machine Kali)
#
# CADRE : ces tests se limitent à la RECONNAISSANCE et au BALAYAGE DE PORTS.
#         Aucune exploitation, aucune écriture dans un registre Modbus.
#         À n'exécuter que dans le laboratoire virtualisé isolé.
set -uo pipefail

PLC_IP="${1:-192.168.20.50}"
HMI_IP="${2:-192.168.20.60}"
OUT="results-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$OUT"

banner() { printf '\n\033[1;34m=== %s ===\033[0m\n' "$1"; }

banner "T1 — Reconnaissance de la zone OT depuis la zone IT"
echo "Source : $(ip -4 addr show scope global | awk '/inet/ {print $2; exit}')"
nmap -Pn -sn 192.168.20.0/24 | tee "$OUT/t1-reconnaissance.txt"

banner "T2 — Découverte du service Modbus TCP (port 502)"
nmap -Pn -p 502 --script modbus-discover "$PLC_IP" | tee "$OUT/t2-modbus.txt"

banner "T3 — Découverte des services de supervision et d'administration"
nmap -Pn -sV -p 1881,8080,8443 "$HMI_IP" | tee "$OUT/t3-services.txt"

banner "Interprétation"
cat <<'MSG'
  open      la cible a répondu SYN/ACK    -> service joignable, segmentation en échec
  closed    la cible a répondu RST        -> le paquet ATTEINT la machine, segmentation en échec
  filtered  aucune réponse exploitable    -> le paquet n'atteint jamais la cible :
                                             un équipement de filtrage l'a supprimé en chemin

  Résultat attendu pour ce laboratoire : filtered sur 502, 1881, 8080 et 8443.
MSG

banner "Test complémentaire recommandé (T7)"
cat <<'MSG'
  Une politique qui bloque TOUT n'est pas du Zero Trust, c'est une déconnexion.
  Depuis la source LÉGITIME (poste d'exploitation), le port 502 doit répondre "open" :

      nmap -Pn -p 502 <ip-du-plc>

  Puis consultez le journal de filtrage d'OPNsense pour identifier quelle règle a
  traité chacun des deux paquets. C'est ce test qui démontre la GRANULARITÉ de la
  politique, et non son caractère bloquant.
MSG

echo
echo "[OK] Résultats enregistrés dans $OUT/"
