# Tests de segmentation

## Cadre

Ces tests se limitent à la **reconnaissance et au balayage de ports**. Aucune exploitation
de vulnérabilité, aucune élévation de privilèges, aucune écriture dans un registre Modbus.

Ils ne doivent être exécutés que dans le laboratoire virtualisé isolé, dont les réseaux sont
en mode *host-only* et n'ont aucune connectivité vers un réseau physique.

## Exécution

```bash
./run-scans.sh [ip-du-plc] [ip-de-l-ihm]
# par défaut : 192.168.20.50 et 192.168.20.60
```

Les sorties sont enregistrées dans un dossier horodaté `results-AAAAMMJJ-HHMMSS/`.

## Interpréter les résultats

| État nmap | Signification | Ce que cela dit de l'architecture |
|---|---|---|
| `open` | Réponse `SYN/ACK` | Service joignable — segmentation en échec |
| `closed` | Réponse `RST` | Le paquet **atteint la machine** — segmentation en échec malgré tout |
| `filtered` | Aucune réponse exploitable | **Le paquet n'atteint jamais la cible** — un filtre l'a supprimé en chemin |

`filtered` est le résultat recherché sur 502, 1881, 8080 et 8443 depuis la zone IT.

La distinction entre `closed` et `filtered` est essentielle : `closed` signifierait que le
paquet a traversé le pare-feu et atteint la machine sans y trouver de service. Ce serait un
échec de segmentation, même en l'absence de service exposé.

## Le test qui manque

Une politique qui bloque tout n'est pas du Zero Trust, c'est une déconnexion. Le test le
plus démonstratif consiste à vérifier que le flux **autorisé** fonctionne :

```bash
# Depuis le poste d'exploitation légitime -> attendu : open
nmap -Pn -p 502 192.168.20.50

# Depuis la machine d'audit               -> attendu : filtered
nmap -Pn -p 502 192.168.20.50
```

Puis consulter le journal de filtrage d'OPNsense pour identifier quelle règle a traité
chacun des deux paquets.
