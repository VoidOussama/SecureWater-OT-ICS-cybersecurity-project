# Tests de sécurité

## Cadre éthique

Tous les tests ont été conduits **exclusivement** dans le laboratoire virtualisé, sur des machines créées pour le projet. Les réseaux des zones testées sont en mode *host-only* : ils n'ont **aucune connectivité vers le réseau physique de l'entreprise ni vers Internet**.

Les actions réalisées relèvent de la **reconnaissance et du balayage de ports**. Aucune exploitation de vulnérabilité, aucune tentative d'élévation de privilèges et aucune écriture dans un registre Modbus n'ont été effectuées.

## Objectifs de vérification

1. Les zones sont-elles effectivement isolées, le trafic inter-zones étant contraint de traverser le pare-feu ?
2. Les services industriels et de supervision sont-ils joignables depuis la zone IT ?
3. Le comportement observé correspond-il à un refus par le pare-feu, ou simplement à une absence de service ?
4. Quels événements la chaîne de détection produit-elle lors de ces tentatives ?

## Environnement et point de départ

| Paramètre | Valeur |
|---|---|
| Système | Kali Linux |
| Adresse | `192.168.10.50/24` |
| Réseau | VMnet2 — zone IT |
| Passerelle | `192.168.10.1` (LAN d'OPNsense) |
| Outil | Nmap 7.99 |
| Cibles | `192.168.20.50` et `192.168.20.60` — zone ICS/OT |

Le point de départ correspond au **risque R1** : un poste de la zone IT est supposé compromis, et l'attaquant cherche à progresser vers la zone industrielle. C'est la position la plus réaliste — celle qui résulte d'un hameçonnage réussi.

## Méthodologie du scénario

| Phase | Objectif adverse | Action réalisée | Technique ATT&CK for ICS |
|---|---|---|---|
| 1. Reconnaissance | Identifier les hôtes joignables | Balayage de la zone OT depuis l'IT | `T0846` |
| 2. Découverte du protocole industriel | Confirmer la présence d'un automate, identifier ses registres | Balayage du port 502 avec `modbus-discover` | `T0846.001`, `T0861` |
| 3. Découverte de la supervision | Identifier l'IHM et l'administration | Balayage de 1881, 8080, 8443 avec détection de version | `T0846` |
| 4. Pivot | Émettre une commande vers l'automate | **Non réalisé** — le protocole n'est pas joignable | `T0855` |

La phase 4 n'a pas été menée. Ce n'est pas une omission : les phases 2 et 3 ayant établi que les services ne sont pas joignables, il n'existait aucun canal permettant de la conduire. C'est précisément le résultat attendu.

## T2 — Découverte du service Modbus TCP

```bash
sudo nmap -Pn -p 502 --script modbus-discover 192.168.20.50
```

L'option `-Pn` désactive la découverte d'hôte préalable. Elle est indispensable en environnement filtré : sans elle, l'absence de réponse à une sollicitation ICMP conduirait Nmap à considérer à tort la cible comme éteinte et à ne pas la balayer.

![nmap Modbus](images/18-nmap-modbus-filtered.png)

**Résultat.** `Host is up`, puis `502/tcp filtered mbap` — `mbap` étant l'identifiant du protocole d'application Modbus.

Le script `modbus-discover` **n'a produit aucune sortie**. La technique `T0861 — Point & Tag Identification`, qui consiste à énumérer les registres pour identifier les points à manipuler, est mise en échec au niveau réseau, avant même d'avoir pu s'exécuter.

## T3 — Découverte des services de supervision et d'administration

```bash
sudo nmap -Pn -sV -p 1881,8080,8443 192.168.20.60
```

![nmap services](images/19-nmap-services-filtered.png)

**Résultat.** Les trois ports sont `filtered`. Nmap affiche les noms de service issus de sa table statique — `ibm-mqseries2`, `http-proxy`, `https-alt` — qui **ne correspondent pas aux services réellement hébergés** : ils sont affichés par convention, précisément parce qu'aucune bannière n'a pu être obtenue.

Ce résultat établit que :

- **R4 est traité** — l'IHM FUXA (1881) n'est pas joignable, ce qui ferme le chemin de falsification de la vue opérateur ;
- **R5 est traité** — l'administration OpenPLC (8080) n'est pas joignable, ce qui ferme le chemin le plus dangereux : le téléversement d'un programme automate modifié ;
- **la colonne `VERSION` est vide** — l'adversaire est privé de la recherche de vulnérabilités connues sur les composants.

Portée exacte : ce test démontre que ces ports sont filtrés **depuis cette source**. Il ne démontre pas que les services sont sécurisés en eux-mêmes.

## Interprétation des états de port

| État | Signification | Ce que cela dit de l'architecture |
|---|---|---|
| `open` | Réponse `SYN/ACK` : le service accepte les connexions | Service joignable — segmentation en échec |
| `closed` | Réponse `RST` : le paquet a atteint la machine, aucun service n'écoute | Le paquet **atteint la cible** — segmentation en échec malgré tout |
| `filtered` | Aucune réponse exploitable | **Le paquet n'atteint jamais la cible** : un équipement de filtrage l'a supprimé en chemin |

L'état `filtered` établit que le paquet a été **supprimé par OPNsense avant d'atteindre la machine industrielle**. C'est la démonstration expérimentale que la règle de filtrage est active et effective.

La suppression silencieuse — plutôt qu'un rejet explicite — est le comportement recherché : elle ne renvoie aucune information à l'émetteur et rend la cartographie du réseau coûteuse.

## Synthèse

| Réf. | Test | Mécanisme sollicité | Résultat | Conclusion |
|---|---|---|---|---|
| T1 | Reconnaissance de la zone OT depuis l'IT | Segmentation VMnet + routage | Hôte `up`, aucun service accessible | Segmentation effective |
| T2 | Balayage du port 502 avec `modbus-discover` | Filtrage OPNsense | `502/tcp filtered`, script sans sortie | Accès direct à l'automate bloqué — R3 traité |
| T3 | Balayage de 1881, 8080, 8443 avec `-sV` | Filtrage OPNsense | Trois ports `filtered`, aucune version | IHM et administration inaccessibles — R4 et R5 traités |
| T4 | Protection SSH par Fail2Ban | Fail2Ban + journal SSH | Test non réalisé | — |
| T5 | Détection du balayage par Suricata | Suricata en `af-packet` | Aucune alerte relevée | — |
| T6 | Remontée des événements au SOC | Agents Wazuh + Manager | Deux agents enrôlés, **agent DMZ déconnecté** | Chaîne partiellement opérationnelle — R12 non traité |
| T7 | Fonctionnement du flux autorisé `IT → OT / 502` | Règle 1 du groupe ZeroTrust | Test non réalisé | — |

**Le volet prévention est démontré. Le volet détection ne l'est pas.**

## Le test qui manque le plus

> Une politique qui bloque tout n'est pas une politique Zero Trust, c'est une déconnexion.

Le test **T7** est celui qui apporterait le plus de valeur : vérifier que le flux légitime `IT → OT` sur le port 502 fonctionne effectivement depuis la source autorisée.

```bash
# Depuis le poste d'exploitation (source légitime) — attendu : open
nmap -Pn -p 502 192.168.20.50

# Depuis la machine d'audit — attendu : filtered
nmap -Pn -p 502 192.168.20.50
```

Puis consulter le journal de filtrage d'OPNsense pour identifier quelle règle a traité chacun des deux paquets.

Ce seul test transformerait le résultat de T2 en **démonstration positive de la granularité** de la politique, au lieu d'une simple constatation de blocage. Il lèverait aussi l'ambiguïté sur la définition de la source « Attacker » : si elle est correctement définie comme un alias contenant `192.168.10.50`, alors le fait que T2 retourne `filtered` malgré la règle 1 signifie que la politique **distingue effectivement le poste légitime de la machine d'audit** — ce qui serait le meilleur résultat possible.

## Rejouer les tests

```bash
cd tests
./run-scans.sh 192.168.20.50 192.168.20.60
```

Le script enregistre les sorties horodatées dans un dossier `results-AAAAMMJJ-HHMMSS/`.
