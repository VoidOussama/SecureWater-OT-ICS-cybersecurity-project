# Politique de filtrage Zero Trust

## Pourquoi le réseau porte toute la sécurité

Modbus TCP n'intègre aucune authentification, aucun chiffrement, aucun contrôle d'intégrité cryptographique et aucune protection contre le rejeu. Ces quatre absences ne sont pas des vulnérabilités au sens d'un défaut d'implémentation : elles sont **inhérentes à la conception du protocole** et ne peuvent pas être corrigées par un correctif.

Le protocole ne permet pas non plus de restreindre un client aux seuls codes de lecture. Un client autorisé à atteindre le port 502 dispose de l'ensemble des codes de fonction :

| Code | Fonction | Nature |
|---|---|---|
| `0x01` | Read Coils | Lecture — divulgation de l'état du procédé |
| `0x03` | Read Holding Registers | Lecture — divulgation des mesures |
| `0x04` | Read Input Registers | Lecture — valeur brute du capteur |
| `0x05` | Write Single Coil | **Écriture — action directe sur le procédé** |
| `0x06` | Write Single Register | **Écriture — altération d'un seuil ou d'une consigne** |

> Autoriser la supervision revient techniquement à autoriser la commande.

D'où la décision structurante : **restreindre au maximum l'ensemble des machines capables d'ouvrir une session TCP sur le port 502.**

## Le principe du refus par défaut

Deux modèles opposés existent.

**Liste noire** — tout est permis sauf ce qui est explicitement interdit. Chaque nouveau service, chaque nouvelle machine est autorisé sans décision. L'administrateur doit anticiper toutes les menaces : c'est impossible.

**Liste blanche** — tout est interdit sauf ce qui est explicitement permis. Chaque autorisation résulte d'une décision documentée. Un service ajouté sans autorisation ne fonctionne simplement pas.

SecureWater OT applique le second. Sa conséquence est que la sécurité ne dépend pas de l'exhaustivité des **menaces connues**, mais de l'exhaustivité des **besoins fonctionnels identifiés** — un ensemble beaucoup plus petit et mieux maîtrisé.

Ce principe est issu du NIST SP 800-207, qui pose que l'accès à une ressource ne doit jamais être accordé sur la base de la localisation réseau du demandeur. Il implique une conséquence contre-intuitive : **le fait d'être « à l'intérieur » du réseau ne confère aucun droit.** La machine Kali est à l'intérieur du réseau et ne dispose d'aucun accès aux services industriels.

## Représentation logique

![Politique Zero Trust](images/02-politique-zero-trust.png)

## Matrice de flux

| Source | Destination | Service / Port | Action | Justification de sécurité |
|---|---|---|---|---|
| IT | ICS/OT | Modbus TCP `502` | **PASS** | Seul flux industriel autorisé. Restreint au port 502 : aucun accès à l'administration (8080) ni à la supervision (1881). |
| IT | DMZ | HTTPS `443` | **PASS** | Accès aux services exposés. TLS protège la session contre l'écoute passive depuis la zone IT. |
| ICS/OT | SOC | Wazuh `1514` | **PASS** | Remontée des journaux. Flux unidirectionnel : l'agent initie, le manager répond. |
| DMZ | SOC | Wazuh `1514` | **PASS** | Remontée des alertes Suricata et Fail2Ban. Même logique. |
| Attacker | ICS/OT | tout | **BLOCK** | Aucune raison fonctionnelle ne justifie qu'une machine d'audit atteigne l'automate. |
| Attacker | DMZ | tout | **BLOCK** | Empêche l'utilisation de la DMZ comme point de rebond. |
| DMZ | ICS/OT | tout | **BLOCK** | Principe de la DMZ industrielle : une zone tampon n'est jamais un relais vers la conduite. |
| SOC | toutes zones | tout | **BLOCK** | Le SOC reçoit, il n'initie pas. Protège l'intégrité de la preuve. |
| ICS/OT | WAN | tout | **BLOCK** | Aucun besoin sortant. Ferme le canal de commande et de contrôle. |
| ICS/OT | IT | tout | **BLOCK** | La zone critique n'initie pas vers la moins fiable. |
| `any` | `any` | tout | **BLOCK** | Règle terminale — *Deny by Default*. |

### Lecture par destination

**Ce qui protège l'automate.** Un seul flux entrant est autorisé vers la zone ICS/OT : le port 502 depuis l'IT. Les deux interfaces les plus dangereuses de la zone — l'administration OpenPLC (8080), qui permet de **téléverser un programme**, et l'IHM FUXA (1881), qui permet de **piloter le procédé** — ne sont joignables depuis aucune autre zone.

**Ce qui protège du pivot.** Les deux chemins classiques sont fermés : le chemin direct `IT → OT` est réduit à un port, et le chemin indirect `IT → DMZ → OT` est fermé par la règle `DMZ → OT : BLOCK`. Cette double fermeture traduit la présomption de compromission : la politique reste efficace même si une machine IT ou DMZ est déjà aux mains de l'attaquant.

**Ce qui protège la preuve.** Le SOC ne dispose d'aucune règle sortante. Dans beaucoup d'architectures, la plateforme de supervision est autorisée à interroger les équipements supervisés, ce qui en fait un point de rebond privilégié. Ici, le flux est strictement ascendant.

**Ce qui ferme la sortie.** L'absence de règle `OT → WAN` est aussi importante que les blocages entrants. Un logiciel malveillant introduit dans la zone industrielle a besoin d'un canal sortant pour recevoir ses instructions. Ce canal n'existe pas — et il n'a pas été obtenu par une règle de refus, mais par **l'absence d'écriture d'une règle d'autorisation**. C'est exactement le comportement recherché : la sécurité résulte de ce qui n'a pas été fait.

## Configuration observée

### Interface WAN — vérification du refus par défaut

![WAN deny](images/05-opnsense-wan-deny.png)

Le message est explicite : *« No WAN rules have been defined. All incoming connections on this interface will be blocked until you add a pass rule. »*

Cette absence de règle **n'est pas une omission, c'est la configuration attendue.** L'interface la plus exposée de l'architecture n'accepte aucune connexion entrante. Les 22 entrées affichées correspondent aux règles générées automatiquement — bouclage, anti-usurpation, blocage des réseaux privés en entrée sur WAN — et non à des autorisations applicatives.

### Règles inter-zones

![Règles ZeroTrust](images/06-opnsense-regles-zerotrust.png)

| N° | Règle | Action | Analyse |
|---|---|---|---|
| 1 | `IT → ICS/OT` — `Modbus/502` | PASS | Autorisation la plus sensible : elle ouvre le protocole industriel à la zone la moins fiable. Le port est bien restreint, mais la source reste la zone IT entière. Une restriction à l'adresse du seul poste d'exploitation serait préférable. |
| 2 | `IT → DMZ` — `HTTPS/443` | PASS | Périmètre correct, session chiffrée. |
| 3 | `ICS/OT → SOC` — `1514` | PASS | Sens correct : l'agent initie vers le manager. Le port `1515`, requis pour l'enrôlement, n'apparaît pas. |
| 4 | `DMZ → SOC` — `1514` | PASS | Même remarque sur `1515` — cause plausible de l'échec d'enrôlement constaté. |
| 5 | `Attacker → ICS/OT` — `any/502` | BLOCK | Blocage du pivot direct. **Ne fonctionne que si « Attacker » est un alias d'adresse IP** : Kali et le poste Windows partagent VMnet2, aucune distinction par interface n'est possible. |
| 6 | `Attacker → DMZ` — `any` | BLOCK | Blocage du rebond. Même remarque sur la définition de la source. |

## Portée réelle de la protection

Un rapport d'ingénieur doit distinguer ce que l'architecture empêche de ce qu'elle n'empêche pas.

| Scénario de progression | Traité ? | Explication |
|---|---|---|
| Poste IT compromis → administration OpenPLC (8080) | **Oui** | Port non autorisé, état `filtered` observé |
| Poste IT compromis → IHM FUXA (1881) | **Oui** | Port non autorisé, état `filtered` observé |
| Poste IT compromis → Modbus TCP (502) | Partiellement | Le port est autorisé pour la zone IT. Le filtrage restreint le service, pas la source |
| Poste IT compromis → autre machine de la zone IT | **Non** | Le trafic intra-VMnet ne traverse pas le pare-feu |
| Machine DMZ compromise → zone OT | **Non** | Chemin direct de niveau 2 par `ens33`, hors du champ du pare-feu |
| Machine OT compromise → Internet | **Oui** | Aucune règle de passage sortante |
| Machine OT compromise → zone IT | **Oui** | Aucune règle dans ce sens |
| SOC compromis → zones supervisées | **Oui** | Aucune règle sortante depuis le SOC |

Cinq scénarios traités sur huit, un partiellement, deux non. Cette évaluation vaut mieux qu'une affirmation générale de protection : elle indique précisément où porter l'effort suivant.

## Mécanismes de dérive à surveiller

Une politique se dégrade rarement d'un coup — elle se dégrade par accumulation de dérogations.

| Mécanisme | Manifestation | Conséquence | Prévention |
|---|---|---|---|
| Règle `any/any` de dépannage | Créée pour débloquer un test, oubliée en place | Segmentation annulée sans aucune alerte | Interdire les règles sans date d'expiration ; revue périodique |
| Autorisation par zone au lieu d'hôte | La règle autorise `192.168.10.0/24` alors qu'un seul poste en a besoin | Toute machine compromise de la zone hérite du droit | Alias d'adresses, restriction à l'hôte |
| Autorisation par plage de ports | `1024-65535` au lieu d'un port précis | Tout service ajouté devient joignable sans décision | Une règle = un service identifié |
| Règle bidirectionnelle par confort | Les deux sens autorisés alors qu'un seul est nécessaire | Le chemin de retour devient un chemin d'attaque | S'appuyer sur le suivi d'état (*stateful*) |

La politique actuelle est exposée au deuxième mécanisme : la règle 1 autorise la zone IT entière vers le port Modbus, alors qu'un seul poste devrait en bénéficier.

## Limite fondamentale du filtrage

Un pare-feu ne peut appliquer une règle qu'**au trafic qui le traverse**. Une politique de segmentation ne se vérifie donc pas en relisant les règles, mais en vérifiant la topologie effective de chaque machine.

La méthode de vérification est double : relever les interfaces (`ip a`), puis confirmer par un test actif que le trafic inter-zones est bien vu par le pare-feu (journal de filtrage, `tcpdump` sur l'interface concernée).

C'est exactement ce point qui a révélé le contournement documenté dans [`05-findings.md`](05-findings.md).
