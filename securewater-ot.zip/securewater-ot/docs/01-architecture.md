# Architecture

## Principes de conception

L'architecture ne résulte pas d'une accumulation de technologies mais de quatre principes, appliqués dans cet ordre.

1. **Point de contrôle unique.** Tout flux inter-zones traverse un seul équipement de filtrage, où la politique est définie, appliquée et journalisée. Un seul point de contrôle signifie un seul endroit à auditer.
2. **Refus par défaut.** Aucune communication n'est autorisée tant qu'une règle explicite ne l'a pas permise. La politique se construit en liste blanche.
3. **Moindre privilège réseau.** Une autorisation porte sur un couple source/destination et un service précis. Jamais une plage d'adresses entière, jamais une plage de ports.
4. **Présomption de compromission.** L'architecture est conçue en supposant qu'une machine est déjà compromise. La question n'est pas d'empêcher l'intrusion initiale, mais de limiter ce qu'elle permet d'atteindre.

## Vue d'ensemble

![Architecture globale](images/01-architecture-globale.png)

Le pare-feu occupe la position centrale avec cinq interfaces. Aucune liaison directe entre deux zones n'existe par conception : la seule adjacence prévue passe par le pare-feu.

## Zones de confiance

Le découpage applique la notion de **zone** au sens de la norme IEC 62443 : un ensemble d'actifs partageant les mêmes exigences de sécurité, dont les communications avec l'extérieur passent par un **conduit** contrôlé.

| Zone | Rôle | Criticité | Exigence dominante |
|---|---|---|---|
| **IT** | Poste bureautique d'exploitant et machine d'audit | Faible — zone la moins fiable | Aucune confiance implicite ; toute sortie vers l'OT doit être justifiée |
| **DMZ** | Zone tampon hébergeant les fonctions de sécurité exposées | Moyenne | Ne doit jamais constituer un relais vers la zone OT |
| **ICS/OT** | Automate, IHM et procédé simulé | **Élevée** | Disponibilité et intégrité du procédé, surface d'exposition minimale |
| **SOC** | Collecte, corrélation et visualisation des événements | Élevée | Reçoit des flux, n'en initie aucun vers les zones supervisées |

La logique de flux qui en découle est volontairement **asymétrique** : les zones critiques émettent vers le SOC mais n'en reçoivent rien, et la zone la moins fiable ne dispose que d'une autorisation étroite vers la plus critique.

## Plan d'adressage

| Réseau virtuel | Mode | Zone | Sous-réseau | Passerelle | Usage |
|---|---|---|---|---|---|
| VMnet1 | Host-only | — | `192.168.127.0/24` | — | Réseau VMware par défaut, **non utilisé** |
| VMnet2 | Host-only | IT / audit | `192.168.10.0/24` | `192.168.10.1` — LAN | Windows 11, Kali Linux |
| VMnet3 | Custom | ICS/OT | `192.168.20.0/24` | `192.168.20.1` — OPT1 | OpenPLC, FUXA, Sysmon, agent Wazuh |
| VMnet4 | Host-only | DMZ | `192.168.40.0/24` | `192.168.40.1` — OPT2 | Suricata, Fail2Ban, agent Wazuh |
| VMnet5 | Host-only | SOC | `192.168.50.0/24` | `192.168.50.1` — OPT3 | Wazuh Manager, Indexer, Dashboard |
| VMnet6 | Host-only | — | `192.168.60.0/24` | — | Déclaré, **non utilisé** |
| VMnet8 | NAT | Accès extérieur | `192.168.95.0/24` | `192.168.95.139` (DHCP) | Accès sortant temporaire d'installation |

> VMnet1 et VMnet6 sont déclarés sans être affectés. Un réseau déclaré et inutilisé constitue une surface d'exposition sans justification fonctionnelle : leur suppression fait partie du plan de correction.

### Le choix du mode host-only

Trois zones sur quatre sont en mode *host-only*. C'est une décision de sécurité, pas de commodité : ce mode rend **structurellement impossible** qu'un balayage lancé depuis la machine d'audit atteigne un équipement réel du réseau de l'entreprise.

L'interface WAN, en NAT, n'a été nécessaire que pour télécharger les paquets pendant l'installation. Dans une installation réelle, un dépôt local hors ligne serait la solution appropriée.

## Interfaces du pare-feu

![Console OPNsense](images/04-opnsense-interfaces.png)

| Interface | Périphérique | Adresse | Zone desservie | Réseau virtuel |
|---|---|---|---|---|
| LAN | `le1` | `192.168.10.1/24` | IT / audit | VMnet2 |
| OPT1 | `le2` | `192.168.20.1/24` | ICS/OT | VMnet3 |
| OPT2 | `le3` | `192.168.40.1/24` | DMZ | VMnet4 |
| OPT3 | `le4` | `192.168.50.1/24` | SOC | VMnet5 |
| WAN | `le0` | `192.168.95.139/24` (DHCP) | Accès sortant NAT | VMnet8 |

Version installée : **OPNsense 26.7 (amd64)**.

Deux remarques d'exploitation. Les interfaces des zones critiques portent les noms génériques `OPT1`, `OPT2`, `OPT3` : rien ne distingue visuellement l'interface industrielle de celle du SOC, ce qui augmente le risque d'erreur lors de l'écriture d'une règle. Leur renommage en `OT`, `DMZ`, `SOC` est recommandé. Par ailleurs, une adresse WAN en DHCP rend toute règle la référençant dépendante d'un bail — acceptable en laboratoire, à proscrire en production.

## Inventaire des machines

![Inventaire VMware](images/03-inventaire-vm.png)

| Machine | Système | Zone | Réseau | Adresse | Rôle |
|---|---|---|---|---|---|
| Kali Linux | Kali Linux | IT | VMnet2 | `192.168.10.50` | Plateforme d'audit |
| Windows 11 | Windows 11 | IT | VMnet2 | *non relevée* | Poste bureautique d'exploitant |
| OPNsense | OPNsense 26.7 | Transverse | VMnet2/3/4/5/8 | `.10.1` · `.20.1` · `.40.1` · `.50.1` · `.95.139` | Pare-feu et point de contrôle |
| UBUNTO OT | Ubuntu 24.04.4 LTS | ICS/OT | VMnet3 | `192.168.20.60` | OpenPLC, FUXA, Sysmon, agent Wazuh |
| DMZ | Ubuntu 24.04.4 LTS | DMZ | VMnet4 **+ VMnet3** | `192.168.40.10` **et `192.168.20.100`** | Suricata, Fail2Ban, agent Wazuh — *bi-domiciliée, voir findings* |
| Wazuh Manager | Ubuntu 24.04 LTS | SOC | VMnet5 | `192.168.50.10` | Manager, Indexer, Dashboard |

### Vérification de l'appartenance aux zones

L'adressage effectif de chaque machine a été relevé par `ip a`. Cette vérification n'est pas une formalité : c'est elle qui a révélé l'écart de topologie de la machine DMZ.

**Zone IT** — une seule interface, `192.168.10.50/24` :

![Adressage Kali](images/07-adressage-kali-it.png)

**Zone ICS/OT** — `192.168.20.60/24`, plus une pile Docker inactive dont le retrait est recommandé :

![Adressage OT](images/08-adressage-ot.png)

**Zone DMZ** — deux interfaces actives dans deux zones différentes :

![Adressage DMZ](images/09-adressage-dmz-dualhomed.png)

Ce dernier relevé est analysé en détail dans [`05-findings.md`](05-findings.md).

## Dimensionnement

![Ressources VM Wazuh](images/10-vm-wazuh-ressources.png)

La machine la plus exigeante est celle du SOC : l'indexer Wazuh repose sur un moteur d'indexation dérivé d'OpenSearch, gourmand en mémoire.

Configuration relevée : **4,9 Go de RAM** (5 044 Mo), **3 processeurs virtuels**, **40 Go de disque**, carte réseau en mode *Custom* sur VMnet5.

Ce dimensionnement est **en dessous des recommandations** de Wazuh pour un déploiement mono-nœud regroupant manager, indexer et dashboard. C'est une cause plausible de la déconnexion d'agent constatée.

## Transposition du modèle Purdue

| Niveau | Fonction de référence | Dans SecureWater OT |
|---|---|---|
| Niveau 0 | Procédé physique : capteurs, actionneurs | Réservoir et capteur de niveau simulés |
| Niveau 1 | Contrôle : automates programmables | OpenPLC — zone ICS/OT |
| Niveau 2 | Supervision de zone : SCADA, IHM | FUXA — zone ICS/OT |
| Niveau 3 | Opérations de site : historisation | *non implémenté* |
| DMZ industrielle | Seul point d'échange entre niveaux 3 et 4 | Zone DMZ — Suricata, Fail2Ban |
| Niveaux 4/5 | Systèmes d'entreprise, bureautique | Zone IT |
| Transverse | Supervision de sécurité | Zone SOC — non prévue par le modèle Purdue |

**Deux écarts assumés.** Les niveaux 1 et 2 ne sont pas séparés — OpenPLC et FUXA partagent `192.168.20.0/24`, alors qu'une installation réelle séparerait conduite et contrôle. Le niveau 3 est absent, ce qui rend la DMZ industrielle adjacente au niveau 2. La maquette compresse donc la pile Purdue sur quatre zones au lieu de six.

Le modèle est une **inspiration de conception**, pas une implémentation complète.

## Risques introduits par la virtualisation

| Risque | Manifestation | Mesure appliquée |
|---|---|---|
| Erreur de raccordement | Carte sur le mauvais VMnet, ou en mode *bridged* au lieu de *host-only* | Vérification systématique par `ip a` — c'est ce qui a détecté l'écart DMZ |
| Machine multi-domiciliée | Une machine porte plusieurs cartes et contourne le pare-feu | **Non appliquée avec rigueur sur la machine DMZ** |
| Compromission de l'hyperviseur | Accès simultané à toutes les zones | Irréductible sur une maquette mono-hôte — hors périmètre, assumé |
| Mutualisation des ressources | La saturation d'une machine dégrade les autres | Aucune — peut fausser l'interprétation d'un test de disponibilité |

Dans une installation réelle, la séparation reposerait sur des équipements physiques distincts et des VLAN, non sur des commutateurs virtuels partageant un même hôte.
