# Analyse des risques

## Méthode

Cinq temps : identification des actifs, identification des scénarios de menace, évaluation de la vraisemblance et de l'impact, détermination du niveau de risque brut, puis mesure de traitement et risque résiduel.

### Actifs à protéger

| Réf. | Actif | Pourquoi il compte |
|---|---|---|
| A1 | Automate OpenPLC et sa logique de contrôle | Sa compromission produit un effet sur le procédé physique |
| A2 | Intégrité des mesures de procédé | Une valeur falsifiée induit une décision d'exploitation erronée |
| A3 | Disponibilité de la chaîne de supervision | Sans IHM, l'exploitant perd la vue sur le procédé |
| A4 | Pare-feu OPNsense | Sa compromission annule toute la politique de sécurité |
| A5 | Plateforme SOC et ses journaux | Leur perte supprime la capacité de détection et d'investigation |

### Échelles

Vraisemblance (V) et impact (I) sur quatre niveaux — 1 faible, 2 modéré, 3 élevé, 4 critique. Niveau de risque = V × I.

| V × I | Niveau | Traitement attendu |
|---|---|---|
| 1 – 3 | Faible | Risque accepté, surveillance simple |
| 4 – 7 | Modéré | Mesure de réduction souhaitable |
| 8 – 11 | Élevé | Mesure obligatoire avant mise en service |
| 12 – 16 | **Critique** | Mesure bloquante, conception à revoir si non traitée |

L'évaluation porte sur le **contexte du laboratoire**, non sur une installation industrielle réelle : elle tient compte de l'absence d'exposition entrante à Internet et de l'absence d'utilisateurs tiers.

## Registre des risques

| Réf. | Risque | Cause | Impact | V | I | Niveau | Mesure appliquée | Résiduel |
|---|---|---|---|:-:|:-:|---|---|---|
| **R1** | Pivot d'un poste IT compromis vers l'OT | Interconnexion IT/OT sans contrôle explicite | Commande non autorisée vers l'automate, arrêt du procédé | 3 | 4 | Critique (12) | Zones sur VMnet distincts ; règle `IT → ICS/OT` restreinte au port 502 ; tout le reste refusé par défaut | Modéré |
| **R2** | Mouvement latéral intra-zone | Pas de micro-segmentation : Kali et Windows partagent `192.168.10.0/24` | Rebond entre machines sans passer par le pare-feu | 3 | 2 | Modéré (6) | Aucune — les flux intra-VMnet ne remontent pas au pare-feu | **Modéré — non traité** |
| **R3** | Accès non autorisé à Modbus TCP | Absence native d'authentification et de chiffrement | Lecture des valeurs, écriture de bobines et de registres | 3 | 4 | Critique (12) | Port 502 joignable seulement depuis les sources autorisées ; balayage depuis l'IT retourne `filtered` | Modéré |
| **R4** | Prise de contrôle de l'IHM FUXA | Interface web sur 1881, authentification par défaut | Falsification de la vue opérateur, commandes vers l'automate | 3 | 3 | Élevé (9) | FUXA confiné en zone OT ; 1881 non joignable depuis l'IT | Modéré |
| **R5** | Prise de contrôle de l'administration OpenPLC | Interface web sur 8080, comptes par défaut | **Téléversement d'un programme modifié** — altération durable de la logique | 2 | 4 | Élevé (8) | Port 8080 non joignable depuis l'IT | Modéré |
| **R6** | Contournement DMZ → OT | Machine DMZ raccordée à `192.168.40.0/24` **et** `192.168.20.0/24` | Le trafic ne traverse pas le pare-feu : la règle de blocage est inopérante | 3 | 4 | Critique (12) | **Écart non corrigé** — voir `05-findings.md` | **Critique — non traité** |
| **R7** | Canal sortant depuis l'OT vers Internet | Accès sortant non maîtrisé | Canal de commande et de contrôle vers un serveur externe | 2 | 4 | Élevé (8) | Aucune règle `OT → WAN` créée : trafic refusé par défaut | Faible |
| **R8** | Règle de filtrage trop permissive | Règle `any/any` créée pour un test et laissée en place | Annulation silencieuse de la segmentation | 3 | 4 | Critique (12) | Politique en liste blanche ; chaque règle porte source, destination et service explicites | Modéré |
| **R9** | Compromission du pare-feu | Interface d'administration accessible, identifiants faibles | Effondrement complet de la politique | 2 | 4 | Élevé (8) | Interface WAN sans règle de passage entrante ; administration depuis l'IT uniquement | Modéré |
| **R10** | Isolation insuffisante des réseaux virtuels | Erreur VMware : VMnet partagé, mode *bridged* | Deux zones distinctes sur le même domaine de diffusion | 2 | 4 | Élevé (8) | Un VMnet par zone en *host-only* ; vérification par `ip a` sur chaque machine | Faible |
| **R11** | Compromission de l'hyperviseur | Vulnérabilité de l'hyperviseur, hôte non durci | Accès simultané à toutes les zones | 1 | 4 | Modéré (4) | Hors périmètre ; laboratoire non exposé | **Hors périmètre** |
| **R12** | Perte de visibilité du SOC | Agent déconnecté, collecte arrêtée | Une attaque se déroule sans qu'aucun événement ne soit collecté | 3 | 3 | Élevé (9) | Agents déployés en OT et DMZ ; **l'agent DMZ est `disconnected`** | **Élevé — non traité** |
| **R13** | Déni de service sur l'automate | Saturation du service Modbus ou de la pile réseau | Perte de commande du procédé, arrêt non contrôlé | 2 | 4 | Élevé (8) | Réduction de la surface par le filtrage ; **aucune limitation de débit** | **Élevé — non traité** |
| **R14** | Force brute sur SSH | Service d'administration exposé, mots de passe faibles | Accès interactif à une machine DMZ ou OT | 3 | 3 | Élevé (9) | Fail2Ban actif sur la machine DMZ | Modéré |

## Synthèse

Quatorze risques : quatre critiques, sept élevés, trois modérés. Après traitement, **quatre demeurent non traités ou insuffisamment traités**.

| Priorité | Risque | Pourquoi c'est le plus urgent |
|---|---|---|
| 1 | **R6** — contournement DMZ → OT | Annule, pour un chemin précis, la mesure centrale de l'architecture |
| 2 | **R12** — perte de visibilité SOC | Prive le SOC de la moitié de sa télémétrie, précisément celle de la zone qui héberge les sondes |
| 3 | **R13** — déni de service | Le filtrage réduit les sources possibles mais n'empêche pas la saturation depuis une source autorisée |
| 4 | **R2** — mouvement latéral intra-zone | Conséquence directe du choix d'un VMnet par zone |

> Une architecture Zero Trust correctement conçue sur le papier peut être invalidée par un unique écart de mise en œuvre — ici, un raccordement réseau supplémentaire sur une seule machine virtuelle.

## Correspondance MITRE ATT&CK for ICS

| Composant | Technique | Effet recherché | Mesure |
|---|---|---|---|
| Réseau OT | `T0842` — Network Sniffing | Capturer les trames Modbus en clair pour cartographier le procédé | Zone OT en domaine de diffusion isolé |
| Automate | [`T0846`](https://attack.mitre.org/techniques/T0846/) — Remote System Discovery | Identifier équipements et services exposés | Balayage depuis l'IT retourne `filtered` |
| Automate | [`T0861`](https://attack.mitre.org/techniques/T0861/) — Point & Tag Identification | Découvrir les registres pour cibler l'action | Port 502 non joignable depuis les zones non autorisées |
| Automate | [`T0855`](https://attack.mitre.org/techniques/T0855/) — Unauthorized Command Message | Émettre une commande légitime en apparence | Réduction des sources capables d'atteindre 502 |
| Automate | `T0836` — Modify Parameter | Modifier une consigne ou un seuil | Même mesure ; **détection non démontrée** |
| IHM | `T0832` — Manipulation of View | L'opérateur voit un état conforme alors que le procédé dérive | IHM confinée, 1881 non joignable depuis l'IT |
| Automate | `T0814` — Denial of Service | Saturer le service ou la pile réseau | **Non traité** — R13 |

La protection repose presque exclusivement sur des mesures de **prévention réseau**. Les capacités de **détection protocolaire** — analyse des codes de fonction Modbus, alerte sur écriture anormale — ne sont pas implémentées.
