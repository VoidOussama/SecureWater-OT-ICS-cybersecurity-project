# Constats d'audit et plan de correction

Un projet de sécurité qui ne publie que ses succès n'est pas un projet de sécurité. Ce document recense les écarts constatés dans la version livrée du laboratoire, avec pour chacun la preuve, l'analyse et la correction.

Le principe appliqué dans tout ce dépôt : **distinguer ce qui est déployé de ce qui est démontré.**

---

## F-01 — La VM DMZ contourne le pare-feu

**Sévérité : critique** · Risque associé : R6 · État : **non corrigé**

### Preuve

![Adressage DMZ](images/09-adressage-dmz-dualhomed.png)

La machine de la DMZ porte deux interfaces actives en plus de la boucle locale :

| Interface | Adresse | Diffusion | Zone |
|---|---|---|---|
| `ens33` | `192.168.20.100/24` | `192.168.20.255` | **ICS/OT** |
| `ens38` | `192.168.40.10/24` | `192.168.40.255` | **DMZ** |

### Analyse

Cette machine est **bi-domiciliée** (*dual-homed*) : elle appartient simultanément à deux zones de confiance de niveaux différents. Toute communication qu'elle établit vers `192.168.20.0/24` emprunte directement le commutateur virtuel VMnet3 et **ne traverse jamais OPNsense**.

La règle `DMZ → OT : BLOCK` existe dans la configuration du pare-feu et **reste inopérante pour cette machine**. Le trafic n'est ni filtré, ni journalisé.

La portée est sérieuse : la machine DMZ est la plus exposée de l'architecture, puisqu'elle porte le service SSH protégé par Fail2Ban. Sa compromission donne un accès direct à la zone industrielle.

### Ce que ce constat enseigne

Cette faille ne réside dans **aucune règle** de pare-feu. Elle réside dans la topologie. Un audit limité à la relecture de la configuration de filtrage aurait conclu à tort que le chemin DMZ → OT était fermé.

> **Une politique de segmentation ne se vérifie pas sur le pare-feu, elle se vérifie sur les machines.**

Le constat n'a pu être établi que par le relevé d'adressage de chaque machine — une étape qu'il est tentant de considérer comme une formalité.

### Question ouverte

Le raccordement était-il **intentionnel** — par exemple pour permettre à Suricata d'observer le trafic de la zone OT — ou résulte-t-il d'une carte réseau laissée en place lors du clonage de la machine ? La réponse détermine la correction.

### Correction

**Si l'objectif est l'observation du trafic OT par Suricata**, l'interface doit être configurée **sans adresse IP** et en mode promiscuité. Elle permet alors la capture sans créer de chemin de routage :

```bash
# Retirer l'adressage IP de l'interface d'observation
sudo ip addr flush dev ens33
sudo ip link set ens33 promisc on up

# Rendre la configuration persistante (netplan)
#   ens33:
#     dhcp4: no
#     dhcp6: no
#     optional: true
```

**Si le raccordement est involontaire**, désactiver l'interface et retirer la carte de la machine virtuelle :

```bash
sudo ip link set ens33 down
# puis : VM Settings -> Network Adapter -> Remove
```

### Vérification attendue

```bash
# 1. Une seule interface adressée
ip -brief addr

# 2. Le trafic DMZ -> OT doit désormais être bloqué ET journalisé
ping -c 3 192.168.20.60          # attendu : échec
# puis dans OPNsense : Firewall -> Log Files -> Live View
#   le paquet doit apparaître, refusé par la règle DMZ -> OT
```

---

## F-02 — Un agent Wazuh sur deux est déconnecté

**Sévérité : élevée** · Risque associé : R12 · État : **non corrigé**

### Preuve

![Agents Wazuh](images/14-wazuh-agents.png)

| ID | Nom | Adresse | Système | Version | État |
|---|---|---|---|---|---|
| 001 | `dmz` | `192.168.40.10` | Ubuntu 24.04.4 LTS | 4.13.1 | **`disconnected`** |
| 002 | `ubuntu-ot` | `192.168.20.50` | Ubuntu 24.04.4 LTS | 4.13.1 | `active` |

### Analyse

Le SOC ne reçoit plus les événements de la DMZ — c'est-à-dire précisément ceux de la zone qui héberge **Suricata et Fail2Ban**. Les alertes réseau et les bannissements SSH ne remontent pas.

L'agent étant enrôlé, il a communiqué avec le manager par le passé : le problème porte sur le **maintien de la connexion**, non sur l'installation.

Le SOC ne voit donc actuellement que la zone OT — la zone la mieux protégée, donc la moins susceptible de produire des événements.

### Causes plausibles

| Hypothèse | Comment la vérifier |
|---|---|
| **(a)** Le port `1515` n'est pas autorisé. La règle `DMZ → SOC` ne couvre que `1514`, or `1515` est requis pour une ré-inscription | Journal de filtrage OPNsense, filtré sur le port 1515 |
| **(b)** Le service `wazuh-agent` est arrêté sur la machine DMZ | `systemctl status wazuh-agent` |
| **(c)** Le manager est en défaut de ressources — la VM SOC est sous-dimensionnée (4,9 Go pour manager + indexer + dashboard) | `free -h` sur le SOC, `/var/ossec/logs/ossec.log` |

### Correction

```bash
# Sur l'agent
sudo systemctl status wazuh-agent
sudo tail -n 100 /var/ossec/logs/ossec.log

# Sur le manager
sudo tail -n 100 /var/ossec/logs/ossec.log
free -h

# Dans OPNsense : ajouter 1515/TCP à la règle DMZ -> SOC
#   Source      : DMZ net
#   Destination : 192.168.50.10
#   Ports       : 1514, 1515
```

### Vérification attendue

L'agent repasse en état `Active` dans le tableau de bord, et des événements en provenance de `192.168.40.10` apparaissent dans l'indexeur.

---

## F-03 — La détection est déployée mais non éprouvée

**Sévérité : élevée** · État : **non corrigé**

### Preuve

![Suricata](images/16-suricata-status.png)
![Sysmon](images/15-sysmon-linux-status.png)
![Fail2Ban](images/17-fail2ban-status.png)

Les trois services sont `enabled` et `active (running)`. Aucune alerte, aucun événement collecté n'a été documenté.

### Analyse

Un service actif n'est pas une détection démontrée. Le tableau suivant fait la distinction explicitement.

| Composant | Déployé | Preuve disponible | Ce qui manque |
|---|---|---|---|
| OPNsense — filtrage | Oui | Interfaces configurées, règles visibles, effet observé au balayage | Extrait du journal de filtrage pendant les tests |
| Wazuh — collecte | Oui | Deux agents enrôlés, tableau de bord accessible | Capture d'une alerte réellement générée ; agent DMZ à remettre en service |
| Sysmon for Linux | Oui | Service actif avec `config.xml` explicite | Événement Sysmon visible dans le tableau de bord Wazuh |
| Suricata | Oui | Service actif en capture `af-packet` | Alerte dans `eve.json` ; jeux de règles chargés ; interface écoutée |
| Fail2Ban | Oui | Service actif | Sortie de `fail2ban-client status sshd` avec un bannissement effectif |
| Corrélation multi-sources | **Non** | — | Règle associant une alerte réseau et un événement système |
| Détection protocolaire Modbus | **Non** | — | Jeu de règles Suricata sur les codes de fonction |
| Zeek | **Non** | — | Déploiement complet |

### Deux causes structurelles

**Le placement de la sonde.** Suricata est en DMZ. Un balayage émis depuis l'IT vers l'OT ne traverse pas nécessairement le segment observé : il est supprimé par le pare-feu **avant** d'atteindre la DMZ. La sonde ne peut pas alerter sur un trafic qu'elle ne voit pas.

**L'efficacité même du filtrage.** Le pare-feu ayant supprimé les paquets en amont, il ne reste aucun trafic à inspecter. C'est un effet de bord classique de la défense en profondeur : plus la prévention est efficace, moins la détection a de matière.

> La source de détection la plus pertinente pour ce scénario n'est donc pas Suricata, mais **le journal de blocage d'OPNsense remonté dans Wazuh.**

### Correction

```bash
# 1. Vérifier l'interface réellement écoutée par Suricata
grep -A5 'af-packet:' /etc/suricata/suricata.yaml
sudo suricata --build-info | head -n 30

# 2. Charger et compter les règles
sudo suricata-update
sudo suricata-update list-sources

# 3. Rejouer un balayage et observer en direct
sudo tail -f /var/log/suricata/eve.json
#   depuis Kali : sudo nmap -Pn -p 1-1000 192.168.20.60

# 4. Remonter le journal du pare-feu dans Wazuh
#   OPNsense : System -> Settings -> Logging -> Remote -> syslog vers 192.168.50.10
#   Wazuh    : ajouter un décodeur pour les journaux pf
```

---

## F-04 — Terminologie : Sysmon for Linux, pas Sysmon Windows

**Sévérité : mineure** · État : **corrigé dans la documentation**

Le schéma d'architecture initial annonçait un « agent Sysmon Windows » dans la zone OT. La capture établit qu'il s'agit de **Sysmon for Linux**, exécuté sur Ubuntu comme service `systemd` :

```
/opt/sysmon/sysmon -i /opt/sysmon/config.xml -service
```

Ce n'est pas un détail de vocabulaire : Sysmon for Windows et Sysmon for Linux ne produisent ni les mêmes identifiants d'événement, ni les mêmes champs, et n'exigent pas les mêmes règles de décodage côté Wazuh.

---

## F-05 — Terminologie : Suricata fonctionne en IDS, pas en IPS

**Sévérité : mineure** · État : **corrigé dans la documentation**

La ligne de commande observée est :

```
/usr/bin/suricata --af-packet -c /etc/suricata/suricata.yaml
```

Le paramètre `--af-packet` seul correspond à une **capture passive**, donc à un fonctionnement en **détection (IDS)** : Suricata observe une copie du trafic, lève des alertes, mais **ne peut pas bloquer** un paquet.

Un fonctionnement en **prévention (IPS)** exigerait explicitement :

- soit le mode `af-packet` inline avec `copy-mode: ips` et une paire d'interfaces appairées ;
- soit une redirection du trafic vers `NFQUEUE` via des règles `iptables`.

La formulation exacte à retenir : *Suricata est déployé en mode détection dans la DMZ.*

---

## F-06 — Adressage incohérent de la machine OT

**Sévérité : mineure** · État : **à trancher**

| Source | Adresse |
|---|---|
| Relevé `ip a` sur la machine OT | `192.168.20.60` |
| Enregistrement Wazuh (`ubuntu-ot`) | `192.168.20.50` |
| Cible du balayage Modbus (T2) | `192.168.20.50` |
| Cible du balayage des services (T3) | `192.168.20.60` |

Trois hypothèses : la zone OT comporte **deux machines distinctes** ; l'adresse a **changé entre les captures** ; ou l'enregistrement Wazuh est **obsolète**.

Il faut trancher et harmoniser l'inventaire — c'est le genre de détail qu'un lecteur attentif relève immédiatement.

---

## F-07 — Réseaux virtuels déclarés et inutilisés

**Sévérité : mineure** · Risque associé : R10 · État : **non corrigé**

`VMnet1` (`192.168.127.0/24`) et `VMnet6` (`192.168.60.0/24`) sont déclarés sans être affectés à une zone. Un réseau déclaré et non utilisé constitue une surface d'exposition sans justification fonctionnelle.

*Correction :* les supprimer dans le *Virtual Network Editor*.

---

## Plan de correction priorisé

| P | Action | Risque traité | Preuve attendue |
|:-:|---|---|---|
| **1** | Supprimer `ens33` de la VM DMZ, ou la reconfigurer sans IP en mode promiscuité | R6 | `ip a` avec une seule interface adressée ; blocage visible dans le journal de filtrage |
| **2** | Rétablir l'agent Wazuh DMZ et autoriser le port `1515` dans la règle `DMZ → SOC` | R12 | Agent `Active` ; événements DMZ dans l'indexeur |
| **3** | Restreindre `IT → ICS/OT / 502` à l'adresse du seul poste d'exploitation via un alias | R3, R8 | Capture de l'alias et de la règle ; T7 réussi depuis la source autorisée, refusé depuis l'audit |
| **4** | Remonter le journal de filtrage d'OPNsense vers Wazuh | R12 | Événements de blocage visibles dans le tableau de bord |
| **5** | Rejouer le balayage et collecter les preuves de détection | — | Extrait `eve.json` ; sortie `fail2ban-client status sshd` |
| **6** | Renommer `OPT1`, `OPT2`, `OPT3` en `OT`, `DMZ`, `SOC` | R8 | Capture de la console après renommage |
| **7** | Supprimer `VMnet1` et `VMnet6` | R10 | Configuration VMware mise à jour |
| **8** | Retirer la pile Docker inactive de la machine OT | — | `docker` absent de la zone la plus critique |
| **9** | Attribuer une adresse statique à l'interface WAN | — | Capture de la console |

## Améliorations d'architecture (moyen terme)

- **Micro-segmentation intra-zone** — isoler chaque machine sur son propre segment, ou activer l'isolation entre ports du commutateur virtuel (R2).
- **Séparation des niveaux Purdue 1 et 2** — placer automate et IHM sur deux segments distincts, avec un conduit contrôlé entre eux.
- **Contrôle applicatif de Modbus** — jeu de règles Suricata sur les codes de fonction, permettant de distinguer une lecture d'une écriture et d'alerter sur toute écriture provenant d'une source non attendue.
- **Limitation de débit sur le port 502** — contenir une saturation même en provenance d'une source autorisée (R13).
- **Durcissement des composants industriels** — changement des identifiants par défaut d'OpenPLC et de FUXA, HTTPS sur les interfaces d'administration, restriction de l'écoute aux interfaces nécessaires.
- **Intégration de Zeek** — le trafic OT est répétitif et prévisible ; une ligne de base permet d'alerter sur toute déviation (nouveau client Modbus, code de fonction inhabituel, fréquence anormale), y compris sans signature.
