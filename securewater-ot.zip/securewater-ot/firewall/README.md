# Pare-feu — OPNsense

Ce dossier accueille la configuration du point de contrôle unique de l'architecture.

## Fichiers à déposer

| Fichier | Contenu |
|---|---|
| `config-anonymise.xml` | Export **System → Configuration → Backups → Download**, expurgé |
| `aliases.md` | Liste des alias définis, en particulier celui utilisé pour la source « Attacker » |
| `regles.md` | Capture ou export des règles par interface |

> **Avant de publier un export**, retirez condensats de mots de passe, clés privées,
> certificats et éventuels identifiants. Le `.gitignore` du dépôt ignore déjà
> `firewall/config-*.xml` par précaution.

## Interfaces

| Interface | Périphérique | Adresse | Zone | Réseau virtuel |
|---|---|---|---|---|
| LAN | `le1` | `192.168.10.1/24` | IT / audit | VMnet2 |
| OPT1 | `le2` | `192.168.20.1/24` | ICS/OT | VMnet3 |
| OPT2 | `le3` | `192.168.40.1/24` | DMZ | VMnet4 |
| OPT3 | `le4` | `192.168.50.1/24` | SOC | VMnet5 |
| WAN | `le0` | `192.168.95.139/24` (DHCP) | Accès sortant NAT | VMnet8 |

Version : **OPNsense 26.7 (amd64)**.

## Créer la politique

### 1. Les alias

**Firewall → Aliases.** L'usage d'alias est ce qui permet d'appliquer le moindre privilège
à la **source**, et pas seulement au service.

| Alias | Type | Contenu |
|---|---|---|
| `IT_NET` | Network | `192.168.10.0/24` |
| `OT_NET` | Network | `192.168.20.0/24` |
| `DMZ_NET` | Network | `192.168.40.0/24` |
| `SOC_NET` | Network | `192.168.50.0/24` |
| `AUDIT_HOST` | Host | `192.168.10.50` — la machine Kali |
| `HMI_HOST` | Host | l'adresse du poste d'exploitation légitime |

### 2. Les règles

**Firewall → Rules**, une catégorie `ZeroTrust_Principles`. Ordre d'évaluation : les règles
sont lues de haut en bas, la première qui correspond s'applique.

| Ordre | Interface | Source | Destination | Port | Action | Log |
|:-:|---|---|---|---|---|:-:|
| 1 | LAN | `AUDIT_HOST` | `OT_NET` | any | **Block** | oui |
| 2 | LAN | `AUDIT_HOST` | `DMZ_NET` | any | **Block** | oui |
| 3 | LAN | `HMI_HOST` | `OT_NET` | 502 | Pass | oui |
| 4 | LAN | `IT_NET` | `DMZ_NET` | 443 | Pass | non |
| 5 | OPT1 | `OT_NET` | `SOC_NET` | 1514, 1515 | Pass | non |
| 6 | OPT2 | `DMZ_NET` | `SOC_NET` | 1514, 1515 | Pass | non |
| 7 | OPT2 | `DMZ_NET` | `OT_NET` | any | **Block** | oui |
| 8 | OPT3 | `SOC_NET` | any | any | **Block** | oui |
| 9 | OPT1 | `OT_NET` | any | any | **Block** | oui |

Les règles de blocage sont placées **avant** les règles de passage : c'est ce qui permet
d'exclure la machine d'audit d'une autorisation accordée à sa zone.

Aucune règle n'est créée sur l'interface **WAN** : l'absence de règle de passage entrante
est la configuration attendue, et le message d'OPNsense le confirme explicitement.

### 3. Journalisation

Cochez **Log** sur toutes les règles de blocage : ces journaux sont la source de détection
la plus pertinente pour un scénario de balayage inter-zones, plus encore que la sonde IDS.

Pour les remonter vers le SOC :
**System → Settings → Logging → Remote** → destination `192.168.50.10`.

## Vérifier

```bash
# Depuis le poste d'exploitation légitime  -> attendu : open
nmap -Pn -p 502 192.168.20.50

# Depuis la machine d'audit                -> attendu : filtered
nmap -Pn -p 502 192.168.20.50
```

Puis **Firewall → Log Files → Live View** pour identifier quelle règle a traité chacun des
deux paquets. C'est ce double test qui démontre la *granularité* de la politique, et non
son seul caractère bloquant.

## Limite à garder en tête

Un pare-feu ne peut appliquer une règle qu'au trafic **qui le traverse**. Une machine
raccordée à deux zones simultanément contourne l'ensemble de la politique sans qu'aucune
règle ne soit en cause. Vérifiez toujours `ip a` sur chaque machine.
