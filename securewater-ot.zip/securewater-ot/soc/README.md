# SOC — Wazuh, Suricata, Sysmon, Fail2Ban

Ce dossier accueille les configurations de la chaîne de détection et de supervision.

## Fichiers à déposer

| Fichier | Contenu |
|---|---|
| `sysmon-config.xml` | Configuration Sysmon for Linux (`/opt/sysmon/config.xml`) |
| `suricata-af-packet.md` | Extrait de `suricata.yaml` : interface écoutée et mode retenu |
| `suricata-rules.md` | Jeux de règles chargés et leur nombre |
| `wazuh-rules.xml` | Règles Wazuh personnalisées, s'il y en a |
| `jail.local` | Configuration Fail2Ban (jails, `maxretry`, `findtime`, `bantime`) |

## Architecture de supervision

| Composant | Niveau observé | Répond à | Zone |
|---|---|---|---|
| OPNsense | Réseau L3/L4 | *Cette communication a-t-elle le droit d'exister ?* | Transverse |
| Suricata | Réseau L3–L7 | *Le contenu de ce trafic autorisé est-il malveillant ?* | DMZ |
| Sysmon for Linux | Système — hôte | *Que s'est-il passé sur cette machine ?* | ICS/OT |
| Fail2Ban | Applicatif — SSH | *Ce comportement d'authentification est-il anormal ?* | DMZ |
| Wazuh | Corrélation | *Ces événements forment-ils un incident ?* | SOC |

La logique est cumulative. OPNsense **décide** ; il ne dit rien du contenu qu'il autorise.
Suricata **inspecte** ce contenu ; il ne voit rien de l'intérieur des machines. Sysmon
**observe** l'hôte ; il n'a aucune vue d'ensemble. Wazuh **rassemble**. Retirer une couche
laisse un angle mort.

## Flux réseau requis par Wazuh

| Flux | Port | Rôle |
|---|---|---|
| Agent → Manager | `1514/TCP` | Transmission continue des événements (chiffrée AES) |
| Agent → Manager | `1515/TCP` | Enrôlement initial et ré-inscription — **souvent oublié dans les règles** |
| Manager → Indexer | `9200/TCP` | Écriture des alertes dans l'index (TLS) |
| Analyste → Dashboard | `443/TCP` | Consultation de l'interface web |
| Dashboard → API Manager | `55000/TCP` | Administration et état des agents |

C'est **toujours l'agent qui initie** la connexion vers le manager, jamais l'inverse. Cette
propriété rend possible l'asymétrie de la politique : le SOC n'a besoin d'aucune règle
sortante vers les zones supervisées.

## Contrainte propre à la zone OT

On n'installe pas librement un agent de sécurité sur un équipement de contrôle : une charge
processeur imprévue, un redémarrage ou une mise en quarantaine automatique peuvent perturber
le cycle automate, et donc le procédé physique.

La stratégie retenue est **passive** : l'agent collecte et transmet, il n'intervient pas.
Aucune fonction de blocage ou de remédiation automatique n'est activée sur la machine
industrielle. C'est conforme aux recommandations du NIST SP 800-82 Rev. 3, qui privilégie
en OT les mesures d'observation aux mesures d'intervention automatique.

## Deux précisions terminologiques

**Sysmon for Linux ≠ Sysmon Windows.** Les identifiants d'événement et les champs diffèrent,
et les règles de décodage Wazuh ne sont pas les mêmes.

**Suricata en `--af-packet` seul = IDS.** C'est une capture passive : il alerte, il ne
bloque pas. Le mode IPS exige `copy-mode: ips` avec une paire d'interfaces appairées, ou
une redirection vers `NFQUEUE`.

## Produire les preuves de détection

Un service actif ne démontre pas une détection. Les preuves attendues :

```bash
# Suricata — alerte réellement déclenchée
sudo tail -f /var/log/suricata/eve.json
sudo suricata --build-info | head -n 30

# Fail2Ban — bannissement effectif
sudo fail2ban-client status
sudo fail2ban-client status sshd

# Wazuh — communication agent/manager
sudo tail -f /var/ossec/logs/ossec.log
```

## Une remarque d'architecture

Suricata est en DMZ, or un balayage IT → OT est supprimé par le pare-feu **avant**
d'atteindre la DMZ. La sonde ne peut pas alerter sur un trafic qu'elle ne voit pas.

Plus la prévention est efficace, moins la détection a de matière à analyser. Pour ce
scénario précis, la source de détection la plus pertinente n'est pas Suricata mais le
**journal de blocage d'OPNsense remonté dans Wazuh**.
