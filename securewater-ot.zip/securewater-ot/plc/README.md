# Programme automate — OpenPLC

Ce dossier accueille la logique de contrôle exécutée par OpenPLC v3.

## Fichiers à déposer

| Fichier | Contenu |
|---|---|
| `reservoir.st` | Le programme en texte structuré (IEC 61131-3) réellement téléversé |
| `variables.md` | Table des variables : nom, type, adressage automate (`%IW`, `%QX`, `%MW`), rôle |
| `seuils.md` | Valeurs numériques des seuils haut et bas, et des alarmes s'il y en a |

## Le procédé

Réservoir d'eau équipé d'un capteur de niveau. Trois grandeurs sont en jeu : le **niveau**
mesuré, le **pourcentage de remplissage** qui en est déduit, et l'**état du procédé**
(remplissage en cours, arrêté, alarme) déterminé par comparaison aux seuils.

La structure de commande attendue est une **régulation par tout ou rien à hystérésis**,
la plus courante pour un remplissage de réservoir :

- niveau sous le seuil bas → la pompe de remplissage est activée ;
- niveau au-dessus du seuil haut → la pompe est arrêtée ;
- entre les deux seuils → l'état précédent est maintenu, ce qui évite les cycles de
  commutation rapides.

## Déployer le programme

1. Interface OpenPLC → **Programs** → *Upload program* → sélectionner le `.st`
2. **Compile program** → vérifier l'absence d'erreur
3. **Dashboard** → *Start PLC*
4. **Monitoring** → confirmer que les variables évoluent

## Preuves à joindre

Deux captures suffisent à démontrer que la logique tourne réellement :

- **Programs** ou **Dashboard** — affichant le nom du programme chargé
  (et non `Blank Program` / `blank_program.st`, qui est le programme vide livré par défaut) ;
- **Monitoring** — variables en cours d'évolution.

## Sécurité

Le port **8080** permet de **remplacer le programme automate**. C'est l'interface la plus
critique de toute la zone OT : une intrusion sur Modbus (502) permet d'agir sur le procédé
pendant la durée de la session ; une intrusion sur 8080 permet d'altérer durablement la
logique, avec un effet qui survit à un redémarrage.

Ce port ne doit être joignable depuis aucune autre zone.
