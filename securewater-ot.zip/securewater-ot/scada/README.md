# Supervision — FUXA

Ce dossier accueille le projet de supervision et la table des registres.

## Fichiers à déposer

| Fichier | Contenu |
|---|---|
| `fuxa-project.json` | Export du projet FUXA (Settings → Project → Export) |
| `registres-modbus.md` | Table des registres : adresse, type, variable automate, sémantique, unité, plage |
| `device-config.md` | Périphérique Modbus déclaré : IP, port, unit-id, période d'interrogation |

## La chaîne fonctionnelle

```
Capteur de niveau
      ↓
   OpenPLC          logique ST, cycle automate
      ↓
 Modbus TCP :502    FUXA est CLIENT, OpenPLC est SERVEUR
      ↓
    FUXA            synoptique : réservoir, jauge, conduite d'arrivée
      ↓
  opérateur
```

## Configurer la liaison

1. **Settings → Connections** → ajouter un périphérique **Modbus TCP**
   - host : `127.0.0.1` si OpenPLC est sur la même machine, sinon son adresse
   - port : `502`
2. Créer les **tags** correspondant aux registres de l'automate
3. Dans l'éditeur de vues, lier chaque widget à son tag

## Un détail qui prête à confusion

Dans **l'éditeur**, un widget de valeur affiche toujours le gabarit `##.##`, y compris
lorsque le tag est correctement lié. La valeur réelle n'apparaît qu'en **mode exécution**.

Une capture prise dans l'éditeur ne démontre donc pas que la liaison Modbus fonctionne.
La preuve à fournir est une capture de la **vue d'exécution** affichant une valeur réelle.

De même, la jauge conserve son échelle par défaut (200 à 2 800) tant qu'elle n'a pas été
paramétrée pour la plage du réservoir.

## Sécurité

Une IHM accessible par navigateur est une application web : elle en a les vulnérabilités.
Le port **1881** doit rester confiné à la zone OT, et les identifiants par défaut doivent
être changés.

Rappel protocolaire : Modbus ne permet pas de restreindre un client à la lecture seule.
Un client autorisé sur le port 502 dispose aussi bien de `0x03` (lecture) que de `0x05` et
`0x06` (écriture de bobine et de registre). Autoriser la supervision revient techniquement
à autoriser la commande — d'où le contrôle strict au niveau réseau.
