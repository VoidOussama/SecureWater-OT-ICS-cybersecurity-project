#!/usr/bin/env bash
# SecureWater OT — FUXA (supervision SCADA/HMI) — zone ICS/OT
# Dépôt officiel : https://github.com/frangoteam/FUXA
set -euo pipefail

INSTALL_DIR="${1:-/opt}"

echo "[*] Installation de Node.js et npm"
apt-get update && apt-get -y install nodejs npm

echo "[*] Clonage du dépôt officiel FUXA"
cd "$INSTALL_DIR"
[ -d FUXA ] || git clone https://github.com/frangoteam/FUXA.git

echo "[*] Installation des dépendances"
cd FUXA/server
npm install

cat <<'MSG'

[OK] FUXA installé. Démarrage : cd /opt/FUXA/server && npm start

  Interface de supervision : http://<ip-de-cette-machine>:1881

Étapes suivantes :
  1. Settings -> Connections -> ajouter un périphérique Modbus TCP
       host = 127.0.0.1 (OpenPLC est sur la même machine)   port = 502
  2. Créer les tags correspondant aux registres de l'automate
  3. Éditeur de vues -> lier chaque widget à son tag
       (dans l'éditeur un widget non lié affiche le gabarit ##.## ;
        la valeur réelle n'apparaît qu'en mode exécution)

RAPPEL DE SÉCURITÉ
  Une IHM accessible par navigateur est une application web : elle en a les
  vulnérabilités. Changez les identifiants par défaut et confinez le port 1881
  à la zone OT.
MSG
