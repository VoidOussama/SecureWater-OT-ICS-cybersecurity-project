#!/usr/bin/env bash
# SecureWater OT — Suricata (détection d'intrusion réseau) — zone DMZ
# Documentation : https://docs.suricata.io/
set -euo pipefail

IFACE="${1:-}"

echo "[*] Ajout du dépôt officiel OISF"
apt-get update && apt-get -y install software-properties-common
add-apt-repository -y ppa:oisf/suricata-stable
apt-get update

echo "[*] Installation de Suricata"
apt-get -y install suricata

if [ -n "$IFACE" ]; then
    echo "[*] Interface d'écoute demandée : ${IFACE}"
    echo "    Renseignez-la dans /etc/suricata/suricata.yaml, section af-packet :"
    echo "      af-packet:"
    echo "        - interface: ${IFACE}"
fi

echo "[*] Téléchargement des jeux de règles"
suricata-update

echo "[*] Activation du service"
systemctl enable --now suricata
systemctl restart suricata
systemctl --no-pager status suricata | head -n 12

cat <<'MSG'

[OK] Suricata actif.

MODE DE FONCTIONNEMENT — point important
  Lancé avec --af-packet seul, Suricata effectue une CAPTURE PASSIVE : il
  fonctionne en DÉTECTION (IDS). Il lève des alertes mais NE BLOQUE PAS.

  Pour un fonctionnement en PRÉVENTION (IPS), il faut explicitement :
    - soit af-packet inline avec copy-mode: ips et une paire d'interfaces appairées
    - soit une redirection du trafic vers NFQUEUE via iptables

  Ne décrivez pas votre déploiement comme un IPS sans l'une de ces configurations.

Vérifier que la détection produit réellement quelque chose :
  tail -f /var/log/suricata/eve.json
  puis lancer un balayage depuis la machine d'audit et observer les alertes.
MSG
