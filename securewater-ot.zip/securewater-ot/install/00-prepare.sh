#!/usr/bin/env bash
# SecureWater OT — Préparation d'une machine Ubuntu Server 24.04 LTS
# À exécuter sur toutes les machines du laboratoire (OT, DMZ, SOC).
set -euo pipefail

echo "[*] Mise à jour du système"
apt-get update && apt-get -y upgrade

echo "[*] Installation des outils de base et de diagnostic"
apt-get -y install \
    curl wget gnupg apt-transport-https ca-certificates lsb-release \
    git build-essential \
    net-tools iproute2 tcpdump nmap-common

echo "[*] Adressage courant :"
ip -brief addr

echo "[OK] Machine prête. Vérifiez que l'interface appartient bien à la zone prévue."
