#!/usr/bin/env bash
# SecureWater OT — Sysmon for Linux (visibilité système) — zone ICS/OT
# Dépôt officiel : https://github.com/microsoft/SysmonForLinux
set -euo pipefail

CONFIG="${1:-/opt/sysmon/config.xml}"

echo "[*] Enregistrement du dépôt Microsoft"
wget -q "https://packages.microsoft.com/config/ubuntu/$(lsb_release -rs)/packages-microsoft-prod.deb" \
     -O /tmp/packages-microsoft-prod.deb
dpkg -i /tmp/packages-microsoft-prod.deb

echo "[*] Installation de Sysmon for Linux"
apt-get update
apt-get -y install sysmonforlinux

if [ -f "$CONFIG" ]; then
    echo "[*] Démarrage avec la configuration ${CONFIG}"
    sysmon -accepteula -i "$CONFIG"
else
    echo "[!] Fichier de configuration absent : ${CONFIG}"
    echo "    Déposez-le puis lancez : sudo sysmon -accepteula -i ${CONFIG}"
fi

systemctl --no-pager status sysmon 2>/dev/null | head -n 10 || true

cat <<'MSG'

[OK] Sysmon for Linux installé.

TERMINOLOGIE — à ne pas confondre
  Sysmon for Linux n'est pas l'agent Sysmon Windows. Les identifiants
  d'événement et les champs diffèrent, et les règles de décodage Wazuh
  ne sont pas les mêmes.

Le fichier config.xml détermine ENTIÈREMENT le périmètre de collecte :
un service actif avec une configuration vide ne collecte rien.
MSG
