#!/usr/bin/env bash
# SecureWater OT — OpenPLC v3 (automate programmable virtuel) — zone ICS/OT
# Dépôt officiel : https://github.com/thiagoralves/OpenPLC_v3
set -euo pipefail

INSTALL_DIR="${1:-/opt}"

echo "[*] Clonage du dépôt officiel OpenPLC v3"
cd "$INSTALL_DIR"
[ -d OpenPLC_v3 ] || git clone https://github.com/thiagoralves/OpenPLC_v3.git

echo "[*] Installation du runtime (peut durer plusieurs minutes)"
cd OpenPLC_v3
./install.sh linux

cat <<'MSG'

[OK] OpenPLC installé.

  Interface d'administration : http://<ip-de-cette-machine>:8080
  Serveur Modbus TCP         : <ip-de-cette-machine>:502

Étapes suivantes :
  1. Programs   -> téléverser le programme .st du dossier plc/ de ce dépôt
  2. Programs   -> Compile program
  3. Dashboard  -> Start PLC
  4. Monitoring -> vérifier que les variables évoluent

RAPPEL DE SÉCURITÉ
  Le port 8080 permet de REMPLACER le programme automate : c'est l'interface la
  plus critique de la zone OT. Elle ne doit être joignable depuis aucune autre zone.
MSG
