#!/usr/bin/env bash
# SecureWater OT — Serveur Wazuh (manager + indexer + dashboard) — zone SOC
# Documentation : https://documentation.wazuh.com/current/installation-guide/
set -euo pipefail

WAZUH_BRANCH="${1:-4.13}"

echo "[*] Téléchargement de l'assistant d'installation Wazuh ${WAZUH_BRANCH}"
curl -sO "https://packages.wazuh.com/${WAZUH_BRANCH}/wazuh-install.sh"

echo "[*] Installation mono-nœud (manager, indexer, dashboard)"
bash ./wazuh-install.sh -a

cat <<'MSG'

[OK] Chaîne Wazuh installée.

  Tableau de bord : https://<ip-de-cette-machine>
  Les identifiants générés sont affichés ci-dessus ET dans wazuh-install-files.tar
  -> conservez ce fichier hors du dépôt Git (il est dans .gitignore)

Ports à ouvrir vers cette machine depuis les zones supervisées :
  1514/TCP  flux permanent des agents
  1515/TCP  enrôlement initial et ré-inscription   <-- souvent oublié
  443/TCP   consultation du tableau de bord

DIMENSIONNEMENT
  Un déploiement mono-nœud regroupant manager + indexer + dashboard demande
  davantage de mémoire que 4,9 Go. Un sous-dimensionnement se manifeste par des
  agents qui passent en état "disconnected" et un tableau de bord lent.
MSG
