#!/usr/bin/env bash
# SecureWater OT — Vérification de l'installation et de l'appartenance aux zones
set -uo pipefail

line() { printf '\n=== %s ===\n' "$1"; }

line "Adressage — chaque machine doit avoir UNE SEULE interface adressée"
ip -brief addr
echo
echo "  Attendu :  OT  -> une adresse en 192.168.20.0/24 uniquement"
echo "             DMZ -> une adresse en 192.168.40.0/24 uniquement"
echo "             SOC -> une adresse en 192.168.50.0/24 uniquement"
echo "  Une machine portant DEUX adresses de zones différentes contourne le pare-feu."

line "Routage"
ip route

line "Services en écoute"
ss -tulnp 2>/dev/null | grep -E 'LISTEN' || true

line "État des services de sécurité"
for svc in suricata fail2ban sysmon wazuh-agent; do
    if systemctl list-unit-files 2>/dev/null | grep -q "^${svc}"; then
        printf '%-14s : %s\n' "$svc" "$(systemctl is-active "$svc" 2>/dev/null)"
    fi
done

line "Atteignabilité de la passerelle"
GW=$(ip route | awk '/default/ {print $3; exit}')
[ -n "${GW:-}" ] && ping -c 2 -W 2 "$GW" >/dev/null 2>&1 \
    && echo "passerelle $GW joignable" \
    || echo "passerelle injoignable ou ICMP filtré (les deux sont possibles)"

echo
echo "[OK] Vérification terminée."
