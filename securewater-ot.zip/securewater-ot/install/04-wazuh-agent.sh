#!/usr/bin/env bash
# SecureWater OT — Agent Wazuh — zones ICS/OT et DMZ
# Documentation : https://documentation.wazuh.com/current/installation-guide/wazuh-agent/
set -euo pipefail

MANAGER_IP="${1:-}"
if [ -z "$MANAGER_IP" ]; then
    echo "Usage : sudo $0 <ip-du-wazuh-manager>"
    echo "Exemple : sudo $0 192.168.50.10"
    exit 1
fi

echo "[*] Prérequis"
apt-get update && apt-get -y install gnupg apt-transport-https curl

echo "[*] Import de la clé GPG du dépôt Wazuh"
curl -s https://packages.wazuh.com/key/GPG-KEY-WAZUH | \
    gpg --no-default-keyring --keyring gnupg-ring:/usr/share/keyrings/wazuh.gpg --import
chmod 644 /usr/share/keyrings/wazuh.gpg

echo "[*] Déclaration du dépôt APT"
echo "deb [signed-by=/usr/share/keyrings/wazuh.gpg] https://packages.wazuh.com/4.x/apt/ stable main" \
    > /etc/apt/sources.list.d/wazuh.list

echo "[*] Installation de l'agent (manager : ${MANAGER_IP})"
apt-get update
WAZUH_MANAGER="$MANAGER_IP" apt-get -y install wazuh-agent

echo "[*] Activation du service"
systemctl daemon-reload
systemctl enable wazuh-agent
systemctl start wazuh-agent

systemctl --no-pager status wazuh-agent | head -n 12

cat <<'MSG'

[OK] Agent installé.

Si l'agent apparaît "disconnected" dans le tableau de bord, vérifiez dans l'ordre :
  1. le service        systemctl status wazuh-agent
  2. les journaux      tail -n 50 /var/ossec/logs/ossec.log
  3. le pare-feu       les ports 1514 ET 1515 doivent être autorisés vers le SOC
  4. le manager        mémoire disponible sur la machine SOC
MSG
