#!/usr/bin/env bash
# SecureWater OT — Fail2Ban (protection du service SSH) — zone DMZ
set -euo pipefail

echo "[*] Installation de Fail2Ban"
apt-get update && apt-get -y install fail2ban

echo "[*] Activation du service"
systemctl enable --now fail2ban
systemctl --no-pager status fail2ban | head -n 10

cat <<'MSG'

[OK] Fail2Ban actif.

Vérifier la jail SSH et les adresses bannies :
  fail2ban-client status
  fail2ban-client status sshd

Cette sortie est la preuve attendue du fonctionnement : un service actif ne
démontre pas qu'un bannissement a réellement eu lieu.
MSG
